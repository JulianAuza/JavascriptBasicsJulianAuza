# GH Searcher

### TODO

* Create HTML for `pushed_at` and `description` (formatted nicely)
* Search by user OR by organization (use radio button to distinguish)
* Display Profile Picture

### Stretch Goals

* Search by Repo
* Display Code
* Order ASC or DESC
* Display Code ??

### Helpful Links

* http://api.jquery.com/jquery.getjson/
* https://developer.github.com/v3/repos/#list-user-repositories
