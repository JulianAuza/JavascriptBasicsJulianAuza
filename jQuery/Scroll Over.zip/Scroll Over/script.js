
$(document).ready(function() {
    
    $('img').hover(function () {

        var src = $(this).attr('src');
        var altsrc= $(this).attr('alt-src');

        $(this).attr("src",altsrc);
        $(this).attr("alt-src",src);
    });

});