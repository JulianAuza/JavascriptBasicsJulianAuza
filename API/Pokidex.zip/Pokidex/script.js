$(document).ready(function(){

for(var i=1;i<152;i++){
var pokeid;
$('p.pokemon').append("<img idnum='"+ i +"'src='http://pokeapi.co/media/img/" + i +".png'/>")
console.log(i);

}   

$('img').click(function(){
    //alert("image clicked")
        $('div.screen').html("");
        $('div.screen2').html("");
        $($(this)).clone().appendTo('div.screen');
        console.log($(this).attr('idnum'));
        
        var num =$(this).attr('idnum');
        var url ="http://pokeapi.co/api/v1/pokemon/" + num + "/";

        // $.get(url, function(pokedata){
        //     var name = pokedata.name;
        //     var imgnum = num;
        //     var type = pokedata.types;
        //     var height = pokedata.height;
        //     var weight = pokedata.weight;
        //  $('div.screen2').html("<p>'" +name + imgnum + type + height + weight+"'</p>");
        // });

   // function getUserRepos (pokedata) {
    $.get(url, function( po ) {
            var name = po.name;
            var imgnum = num;
            var type = po.types;
            var height = po.height;
            var weight = po.weight;
         $('div.screen2').html("<p>'" +name + imgnum + type + height + weight+"'</p>");
        }, "json");

    // Loop Through Repos
   // var avatar = repos[0].owner.avatar_url;
    //$ul.append('<li><img src="' + avatar + '" alt="avatar"></li>');
    //for (var i = 0; i < repos.length; i+=1) {
      // Console Log Each Key We Want
    //  var repo = repos[i];
      // console.log(repo.name);
      // console.log(repo.description);
      // console.log(repo.pushed_at);
      // console.log(repo.html_url);
      // console.log('-----------');
    //   var anchor = '<a href="' + repo.html_url + '">' + repo.name + '</a>';
    //   var desc = '<p>'+ repo.description+'</p>';
    //   var li = '<li>' + anchor + '<br>'+ repo.pushed_at + desc +'</li>';
    //   console.log("THE LIST ITEM STRING WE'VE MADE", li)
    //   $ul.append(li);
     // $ul.append('<li>'repo.pushed_at'</li>');

   // }
  //});
//}
});


});